/*
 * This code is sample code, provided as-is, and we make no
 * warranties as to its correctness or suitability for
 * any purpose.
 *
 * We hope that it's useful to you.  Enjoy.
 * Copyright 2006-12 LearningPatterns Inc.
 */
 
package com.javatunes.teach;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
// TODO - import Component

// TODO - Add Component annotation
@Component("springBook")
@Qualifier("Java") // Optional Qualifier part
public class SpringCourseBook implements InfoSource {
	
	public String getData() {
		return "Dependencies are not so cool";
	}
}