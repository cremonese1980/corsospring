/*
 * This code is sample code, provided as-is, and we make no
 * warranties as to its correctness or suitability for
 * any purpose.
 *
 * We hope that it's useful to you.  Enjoy.
 * Copyright 2006-12 LearningPatterns Inc.
 */
 
package com.javatunes.teach;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;


// TODO - Add Component annotation
@Component("springGuru")
public class JavaInstructor implements Teacher {
	
	// TODO - Add Resource annotation
	// @Resource(name="springBook")  // Commented out to do optional autowiring
	@Autowired  // Optional autowiring
	@Qualifier("Java") // Optional Qualifier part.
	private InfoSource info;
	public void setInfo (InfoSource infoIn) {
      info=infoIn;
  }
	public void teach() {
		System.out.println(info.getData());
	}
}

