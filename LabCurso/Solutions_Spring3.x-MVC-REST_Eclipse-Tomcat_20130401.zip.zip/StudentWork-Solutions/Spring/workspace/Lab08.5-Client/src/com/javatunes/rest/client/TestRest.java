/*
 * This code is sample code, provided as-is, and we make no
 * warranties as to its correctness or suitability for
 * any purpose.
 *
 * We hope that it's useful to you.  Enjoy.
 * Copyright 2006-12 LearningPatterns Inc.
 */

package com.javatunes.rest.client;


import java.net.URI;
import java.util.Collection;
import java.util.Date;

import org.springframework.web.client.RestTemplate;

import com.javatunes.util.MusicItem;

public class TestRest {

	private final static String BASE_URI = "http://localhost:8080/javatunes/rest/items";
	private final static String ID_URI = BASE_URI + "/{id}";

	public static void main(String[] args) {
		RestTemplate rt = new RestTemplate();
	
		MusicItem found;
		
		String deleteId = "3";
/*
 // Comment out to run client more than once		
		found = rt.getForObject(ID_URI, MusicItem.class,deleteId);
		System.out.println("Found item - " + deleteId + " : " + found);
		
		rt.delete(ID_URI,deleteId);
		
		Collection<MusicItem> items = rt.getForObject(BASE_URI, Collection.class);
		System.out.println("All Objects found: " + items);		
*/
		String putId = "6";

		found = rt.getForObject(ID_URI, MusicItem.class,putId);
		System.out.println("Found item - " + putId + " : " + found);
		
		found.setTitle("Changed this");
		rt.put(ID_URI, found, putId);

		found = rt.getForObject(ID_URI, MusicItem.class,putId);
		System.out.println("Found item after put - " + putId + " : " + found);
		
		// Testing POST for create.
		MusicItem newItem = new MusicItem();
		newItem.setTitle("MyTitle");
		newItem.setArtist("Me!");
		newItem.setReleaseDate(new Date());
		MusicItem createdItem = rt.postForObject(BASE_URI, newItem, MusicItem.class);
		System.out.println("Created new item: " + createdItem);
		
		URI createdURI = rt.postForLocation(BASE_URI, newItem);
		System.out.println("Created another new item at location: " + createdURI);
		
	}
}
