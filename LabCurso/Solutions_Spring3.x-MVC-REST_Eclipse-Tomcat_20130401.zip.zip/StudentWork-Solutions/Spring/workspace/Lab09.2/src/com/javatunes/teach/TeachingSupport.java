/*
 * This code is sample code, provided as-is, and we make no
 * warranties as to its correctness or suitablity for
 * any purpose.
 *
 * We hope that it's useful to you.  Enjoy.
 * Copyright 2006-7 LearningPatterns Inc.
 */
 
package com.javatunes.teach;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.annotation.Before;

// TODO Declare class to be an aspect
@Aspect
public class TeachingSupport {

	// TODO declare point cuts
	   @Pointcut("execution(* teach(..))")
	   public void anyTeach() {}

	   @Pointcut("execution(* com.javatunes.teach.InfoSource.getData(..))")
	   public void inInfoSource() {}  

/*	   
   // TODO Declare this method as before advice
   @Before("anyTeach()")
   public void setupDisplayProjector() {
      System.out.println("Turning Display Projector On");
   }
*/
	   
	   @Around("anyTeach()")
	   public void helpTeach(ProceedingJoinPoint joinPoint) throws Throwable {
	     System.out.println("TeacherSupport.helpTeach - before: Turning Display Projector On");
		 joinPoint.proceed();
	     System.out.println("TeacherSupport.helpTeach - after:  Ahhh that drink is good");
	   }

	   @AfterReturning(
	      pointcut="inInfoSource()",
	      returning="retVal")
	   public void checkData(Object retVal) {
	      System.out.println("TeachingSupport.checkData: Data is -  " + retVal);
	   }
  
   
}