/*
 * This code is sample code, provided as-is, and we make no
 * warranties as to its correctness or suitability for
 * any purpose.
 *
 * We hope that it's useful to you.  Enjoy.
 * Copyright 2006-12 LearningPatterns Inc.
 */


package com.javatunes.catalog;

import com.javatunes.util.MusicItem;

import java.util.Collection;


public interface ItemDAO {

  // Get a single item by id
  public MusicItem get(Long id);

  // Get all items
  public Collection<MusicItem> getAll();

  // Get only those items whose title or artist contain the keyword
  public Collection<MusicItem> searchByArtistTitle(String keyword);
  
  // Create a new item with data from given item
  public int create(MusicItem item);
  
  // blowUp() method added to test transactions
  public void blowUp();
  
  // runTest() method added to test transactions and load-time weaving
  public void runTest();  
}
