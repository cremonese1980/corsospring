/*
 * This code is sample code, provided as-is, and we make no
 * warranties as to its correctness or suitability for
 * any purpose.
 *
 * We hope that it's useful to you.  Enjoy.
 * Copyright 2006-12 LearningPatterns Inc.
 */

package com.javatunes.catalog.tx;

import java.math.BigDecimal;
import java.sql.Date;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import com.javatunes.catalog.ItemDAO;
import com.javatunes.util.MusicItem;

public class TestTxImpl implements TestTx {
	
	ItemDAO dao;

	public ItemDAO getDao() {
		return dao;
	}

	public void setDao(ItemDAO dao) {
		this.dao = dao;
	}

	@Transactional(propagation=Propagation.REQUIRED)
	public void runTest() {
        MusicItem createItem = new MusicItem(null, "CD599", "Transaction Blues", 
    		    "We are Committed", Date.valueOf("1984-09-16"), 
    			new BigDecimal("9.99"), new BigDecimal("7.77"));
        System.out.println("TextTxImpl.runTest: Current Transaction name = " + TransactionSynchronizationManager.getCurrentTransactionName());

        dao.create(createItem);        
        dao.blowUp();

	}
}
