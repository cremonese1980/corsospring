/*
 * This code is sample code, provided as-is, and we make no
 * warranties as to its correctness or suitability for
 * any purpose.
 *
 * We hope that it's useful to you.  Enjoy.
 * Copyright 2006-12 LearningPatterns Inc.
 */

package com.javatunes.catalog.jdbc;

import java.util.Date;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.Collection;

import java.math.BigDecimal;

import com.javatunes.catalog.ItemDAO;
import com.javatunes.util.MusicItem;

import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronizationManager;

public class JdbcItemDAO extends JdbcDaoSupport implements ItemDAO 
{
      private static final String INSERT = "INSERT INTO Item (Num, Title, Artist, ReleaseDate, ListPrice, Price) VALUES (?, ?, ?, ?, ?, ?)";

	  private static final String SELECT_ALL_PROPS = "SELECT ItemId, Num, Title, Artist, ReleaseDate, ListPrice, Price FROM Item ";
	  
      private static final String FIND_BY_KEYWORD = SELECT_ALL_PROPS + " WHERE Title LIKE ? OR Artist LIKE ?";      
	  
      private static final String FIND_BY_ID = SELECT_ALL_PROPS + " WHERE ItemId = ?";   
   
	private static final class MIRowMapper implements RowMapper<MusicItem> {
		// This method creates a MusicItem from the result set values, and returns the MusicItem
		public MusicItem mapRow(ResultSet rs, int rowNum) throws SQLException {
	    	  // extract data from the ResultSet
	    	  Long       id  		= rs.getLong("ItemId");
	    	  String     num			= rs.getString("Num");
	    	  String     title       = rs.getString("Title");
	    	  String     artist      = rs.getString("Artist");
	    	  Date       releaseDate = rs.getDate("ReleaseDate");
	    	  BigDecimal listPrice   = rs.getBigDecimal("ListPrice");
	    	  BigDecimal price       = rs.getBigDecimal("Price");

	    	  // initialize the return value
	    	  return new MusicItem(id, num, title, artist, releaseDate, listPrice, price);
     }
	}
	
  // Get a single item by id
  public MusicItem get(Long id) {
	  return getJdbcTemplate().queryForObject (
			  FIND_BY_ID, new Object[]  {id}, new MIRowMapper());
  }

  // Get all items
  public Collection<MusicItem> getAll() {
    return getJdbcTemplate().query(SELECT_ALL_PROPS, new MIRowMapper());
  }

  // Get only those items whose title or artist contain the keyword 
  public Collection<MusicItem> searchByArtistTitle(String keyword) {
      // create the %keyword% wildcard syntax used in SQL LIKE operator
      String wildcarded = "%" + keyword + "%";
	  Object[] args = {wildcarded, wildcarded};
	  return getJdbcTemplate().query(FIND_BY_KEYWORD, args, new MIRowMapper());
  }
  
  // Create a new item with data from given item
  @Transactional(propagation=Propagation.REQUIRES_NEW)
  public int create(MusicItem item) {
      System.out.println("JdbcItemDAO.create: " + TransactionSynchronizationManager.getCurrentTransactionName());	  
		Object[] args = { item.getNum(), item.getTitle(), item.getArtist(), 
				item.getReleaseDate(), item.getListPrice(), item.getPrice() };
		return getJdbcTemplate().update(INSERT, args);	  
  }
  
    // blowUp() method added to test transactions
	public void blowUp () {
        System.out.println("JdbcItemDAO.blowUp: Current Transaction name = " + TransactionSynchronizationManager.getCurrentTransactionName());
		throw new RuntimeException("Blowup");
	}
	
    // runTest() method added to test transactions and load-time weaving.
	@Transactional(propagation=Propagation.REQUIRED)
	public void runTest() {
        MusicItem createItem = new MusicItem(null, "CD599", "Transaction Blues", 
    		    "We are Committed", java.sql.Date.valueOf("1984-09-16"), 
    			new BigDecimal("9.99"), new BigDecimal("7.77"));
        System.out.println("JdbcItemDAO.runTest: Current Transaction name = " + TransactionSynchronizationManager.getCurrentTransactionName());
        create(createItem);
        System.out.println("JdbcItemDAO.runTest: Current Transaction name = " + TransactionSynchronizationManager.getCurrentTransactionName());
        System.out.println("Calling JdbcItemDAO.blowup()");
        blowUp();
	}	
  
}
