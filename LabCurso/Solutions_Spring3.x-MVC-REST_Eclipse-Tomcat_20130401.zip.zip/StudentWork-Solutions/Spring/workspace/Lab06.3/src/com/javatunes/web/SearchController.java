/*
 * This code is sample code, provided as-is, and we make no
 * warranties as to its correctness or suitability for
 * any purpose.
 *
 * We hope that it's useful to you.  Enjoy.
 * Copyright 2006-12 LearningPatterns Inc.
 */
 
package com.javatunes.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.javatunes.catalog.Catalog;

@Controller
@RequestMapping("/search")
public class SearchController {
	
	@Autowired
	Catalog cat;

	@RequestMapping(method = RequestMethod.GET)
	public String get() {
		return "jsp/searchForm.jsp";
	}

	// Handler method to process the search form submission
	@RequestMapping(method = RequestMethod.POST)
	public ModelAndView processSearch(@RequestParam(value="keyword", required=true) String keyword) {
		System.out.println("SearchController.processSearch()");
		return new ModelAndView("/jsp/searchResults.jsp", "results", cat.findByKeyword(keyword));		
	}
}