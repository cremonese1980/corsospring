package com.javatunes.teach;

public interface Teacher {
	public void teach();
}