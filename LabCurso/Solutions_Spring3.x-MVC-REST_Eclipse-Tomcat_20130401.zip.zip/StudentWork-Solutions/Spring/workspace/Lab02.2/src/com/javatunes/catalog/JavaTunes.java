/*
 * This code is sample code, provided as-is, and we make no
 * warranties as to its correctness or suitability for
 * any purpose.
 *
 * We hope that it's useful to you.  Enjoy.
 * Copyright 2006-12 LearningPatterns Inc.
 */
 
package com.javatunes.catalog;

import com.javatunes.util.MusicItem;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class JavaTunes {

	public static void main(String[] args) {
		// Create the application context
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		// Look up the javaTunesCatalog bean 
		Catalog cat = (Catalog)ctx.getBean("javaTunesCatalog");

		// Search by id - returns a single item
		System.out.println(cat.findById(new Long(2)));


		// Look up one of the individual items that are configured
		MusicItem mi = (MusicItem)ctx.getBean("mi1");
		System.out.println("Looked up bean by id = mi1: ");
		System.out.println(mi);
		
		ctx.close();  // Close the context
	}
}