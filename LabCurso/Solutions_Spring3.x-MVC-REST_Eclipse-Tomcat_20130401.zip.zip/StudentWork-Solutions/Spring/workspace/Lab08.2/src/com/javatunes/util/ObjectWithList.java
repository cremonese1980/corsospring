/*
 * This code is sample code, provided as-is, and we make no
 * warranties as to its correctness or suitability for
 * any purpose.
 *
 * We hope that it's useful to you.  Enjoy.
 * Copyright 2006-12 LearningPatterns Inc.
 */
 
package com.javatunes.util;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ObjectWithList {

    private List<MusicItem> list;
    
    public ObjectWithList(List<MusicItem> listIn) {
    	list = listIn;
    }

    public ObjectWithList() {    }

    
    @XmlElementWrapper(name="MyList")
    @XmlElement
    public List<MusicItem> getList() {
        return list;
    }

    public void setList(List<MusicItem> listIn) {
        list = listIn;
    }

}

