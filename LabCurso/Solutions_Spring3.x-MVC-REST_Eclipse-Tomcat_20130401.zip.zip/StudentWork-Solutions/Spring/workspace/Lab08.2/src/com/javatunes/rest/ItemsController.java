/*
 * This code is sample code, provided as-is, and we make no
 * warranties as to its correctness or suitablity for
 * any purpose.
 *
 * We hope that it's useful to you.  Enjoy.
 * Copyright 2006-12 LearningPatterns Inc.
 */
 
package com.javatunes.rest;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.javatunes.catalog.Catalog;
import com.javatunes.util.MusicItem;
import com.javatunes.util.ObjectWithList;

@Controller
@RequestMapping("/items")
public class ItemsController {
	
	@Autowired
	Catalog cat;

    // Optional part - returns wrapped object that can be converted to XML
 	@RequestMapping(headers={"Accept=application/xml"})
    @ResponseBody
	public Object getAllItems() {
		List<MusicItem> results = (List<MusicItem>)cat.getAll();
		return new ObjectWithList(results);  // return wrapped collection
		// return results; // return bare collection, will throw 406 exception (Optional part) with application/xml specified
	}

	
	/*
    // Original - returns JSON if JSON jars  available - otherwise throws 406 error
	@RequestMapping
    @ResponseBody
	public Object getAllItems() {
		List<MusicItem> results = (List<MusicItem>)cat.getAll();
		return results; 
	}
*/	
	
    @RequestMapping("/{id}") 	
    @ResponseBody
	public MusicItem findItem(@PathVariable("id") Long id) {
	   return cat.findById(id);
	}

}