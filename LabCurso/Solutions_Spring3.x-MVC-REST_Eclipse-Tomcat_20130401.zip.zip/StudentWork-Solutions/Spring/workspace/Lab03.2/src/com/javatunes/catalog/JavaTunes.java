/*
 * This code is sample code, provided as-is, and we make no
 * warranties as to its correctness or suitability for
 * any purpose.
 *
 * We hope that it's useful to you.  Enjoy.
 * Copyright 2006-12 LearningPatterns Inc.
 */
 
package com.javatunes.catalog;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.javatunes.util.MusicItem;

public class JavaTunes {

	public static void main(String[] args) {
		// List the two files directly
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("inMemoryItemDAO.xml", "applicationContext.xml");
		
		// Look up the javaTunesCatalog bean 
		Catalog cat = (Catalog)ctx.getBean("javaTunesCatalog");

		// Search by id - returns a single item
		System.out.println(cat.findById(new Long(2)));
/*		
		// The below will now throw an exception if uncommented, since mi1 is an inner bean
		MusicItem mi = (MusicItem)ctx.getBean("mi1");
		System.out.println(mi);
*/		
		
		// Optional - getting names of all defined beans.
		String[] names = ctx.getBeanDefinitionNames();
		System.out.println("\n*** Listing of all bean names:");
		for (String cur : names) {
			System.out.println(cur);
		}
		
		System.out.println("\nClosing the context");
		ctx.close();
	}
}