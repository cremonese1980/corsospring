/*
 * This code is sample code, provided as-is, and we make no
 * warranties as to its correctness or suitability for
 * any purpose.
 *
 * We hope that it's useful to you.  Enjoy.
 * Copyright 2006-12 LearningPatterns Inc.
 */
 
package com.javatunes.catalog;

import com.javatunes.util.MusicItem;

import java.util.Collection;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class JavaTunes {

	public static void main(String[] args) {
		// TODO: Create an ApplicationContext that reads the applicationContext.xml file on the classpath
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		// TODO - Look up the javaTunesCatalog bean 
		Catalog cat = ctx.getBean("javaTunesCatalog", Catalog.class);

		// TODO - the following compiles, but will only run properly when you finish the wiring up in the Spring configuration
		// and the initialization above
		// Search by id - returns a single item
		System.out.println(cat.findById(new Long(1)));
		// Search by keyword - returns up to maxSearchResults items for JavaTunesCatalog
		Collection<MusicItem> col = cat.findByKeyword("a");
		for (MusicItem cur : col) {
		   System.out.println(cur); 
		}
		
		ctx.close();  // Close the context
	}
}