/*
 * This code is sample code, provided as-is, and we make no
 * warranties as to its correctness or suitablity for
 * any purpose.
 *
 * We hope that it's useful to you.  Enjoy.
 * Copyright 2006-7 LearningPatterns Inc.
 */
 
package com.javatunes.teach;

import org.aspectj.lang.ProceedingJoinPoint;

public class TeachingSupport {

   public void setupDisplayProjector() {
      System.out.println("TeacherSupport.setupDisplayProjector -Turning Display Projector On");
   }

   public void helpTeach(ProceedingJoinPoint joinPoint) throws Throwable {
     System.out.println("TeacherSupport.helpTeach - before: Turning Display Projector On");
	 joinPoint.proceed();
     System.out.println("TeacherSupport.helpTeach - after:  Ahhh that drink is good");
   }

   public void checkData(Object retVal) {
      System.out.println("TeachingSupport.checkData: Data is - " + retVal);
   }   
   
}