/*
 * This code is sample code, provided as-is, and we make no
 * warranties as to its correctness or suitability for
 * any purpose.
 *
 * We hope that it's useful to you.  Enjoy.
 * Copyright 2006-12 LearningPatterns Inc.
 */

package com.javatunes.rest;

import java.util.Collection;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.javatunes.catalog.Catalog;
import com.javatunes.util.MusicItem;


@Controller
@RequestMapping("/items")
public class ItemsController {
	
	@Autowired
	Catalog cat;
	
	// Return all items for GET request with URL like /items
 	@RequestMapping(method=RequestMethod.GET)
    @ResponseBody
	public Object getAllItems() {
		List<MusicItem> results = (List<MusicItem>)cat.getAll();
		return results;  // return unwrapped collection - assume we support JSON
	}
 	
    
 	// Return the single item for GET request and URL like /items/2
    @RequestMapping(value="/{id}", method=RequestMethod.GET)
    @ResponseBody
	public MusicItem findItem(@PathVariable("id") Long id) {
    	MusicItem found = cat.findById(id);
    	if (found == null) {
    		throw new IllegalArgumentException("Could not find item with id = " + id);
    	}
       System.out.println("Found item: " + found);
	   return found;
	}

 	// Create an item for POST request and URL like /items
 	@RequestMapping(method=RequestMethod.POST)
 	@ResponseStatus(HttpStatus.CREATED)
 	@ResponseBody
 	public MusicItem createItem (@RequestBody MusicItem item, HttpServletResponse response) {
 		System.out.println("ItemController: createItem called with: " + item);
 		Collection<MusicItem> items = cat.getAll();
 		int size = items.size();
 		item.setId(size+1L);
 		item.setReleaseDate(item.getReleaseDate());
 		item.setNum("CD" + (500+item.getId()));
 		items.add(item);
 		
 		response.setHeader("Location", "/items/" + item.getId());
 		
 		return item;
 	} 	
 	
 	// Delete an item for DELETE request and URL like /items/2
 	@RequestMapping(value="/{id}", method=RequestMethod.DELETE)
 	@ResponseStatus(HttpStatus.NO_CONTENT)
 	@ResponseBody
 	public void deleteItem (@PathVariable("id") Long id) {
 		System.out.println("ItemController: deleteItem called with: " + id);
 		MusicItem toDelete = cat.findById(id);
 		if (toDelete != null) {
 			cat.getAll().remove(toDelete);
 		}
 	}

 	// Update an item for PUT request and URL like /items/2
 	@RequestMapping(value="/{id}", method=RequestMethod.PUT)
 	@ResponseBody
 	public MusicItem updateItem (@PathVariable("id") Long id, @RequestBody MusicItem item) {
 		System.out.println("ItemController: updateItem called with: " + item);
 		MusicItem update = cat.findById(id);
 		System.out.println("updateItem itemIn = " + item);
 		System.out.println("updateItem item to update = " + update);
 		if (update != null) {
 			update.setTitle(item.getTitle());
 			update.setArtist(item.getArtist());
 			update.setPrice(item.getPrice());
 			update.setListPrice(item.getListPrice());
 		}
 		return update;
 	} 	

 	
}