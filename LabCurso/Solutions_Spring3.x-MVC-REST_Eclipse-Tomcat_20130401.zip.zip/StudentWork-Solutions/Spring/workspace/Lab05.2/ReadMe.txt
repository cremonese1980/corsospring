This solution still requires that you add the java agent to the JVM arguments of the run configuration for running the lab (must all be typed without any newlines)

  -javaagent:C:\spring-framework-3.2.2.RELEASE\libs\spring-instrument-3.2.2.RELEASE.jar

