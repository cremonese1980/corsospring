/*
 * This code is sample code, provided as-is, and we make no
 * warranties as to its correctness or suitability for
 * any purpose.
 *
 * We hope that it's useful to you.  Enjoy.
 * Copyright 2006-12 LearningPatterns Inc.
 */

package com.javatunes.catalog;

import java.util.Collection;

import com.javatunes.catalog.tx.TestTx;
import com.javatunes.util.MusicItem;

import org.springframework.context.support.ClassPathXmlApplicationContext;

class JavaTunes
{
   public static void main(String[] args)
   {
   
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");

		// TODO - Look up musicItemDAO and testTx
		ItemDAO dao = ctx.getBean("jdbcItemDAO", ItemDAO.class);
		TestTx test = ctx.getBean("testTx", TestTx.class);


/*		
		// Run the test program - should work with proxies, or load-time weaving
		try {
			test.runTest();
		} catch (Exception e) {
			System.out.println("Exception thrown in TextTx: " + e.getMessage());
		}
*/
		
		// Optional testing for load-time weaving - runs a DAO method that uses self-invocation
		// Will not work correctly with proxies - requires load-time weaving.
		try {
			dao.runTest();
		} catch (Exception e) {
			System.out.println("Exception thrown in ItemDAO: " + e.getMessage());
		}

         // See if the music item was created
         Collection<MusicItem> results = dao.searchByArtistTitle("Transaction");
         System.out.println("\n*** searchByKeyword for 'Transaction' found the following: ***\n");
		 for (MusicItem curItem : results) {
            System.out.println(curItem);
         }
		 System.out.println("\n*** Transaction testing finished ***\n");
		 
		 ctx.close();  // Close the context
   }
}
