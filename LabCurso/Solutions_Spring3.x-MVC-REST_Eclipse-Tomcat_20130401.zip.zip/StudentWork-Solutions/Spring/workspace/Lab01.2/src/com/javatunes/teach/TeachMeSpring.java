/*
 * This code is sample code, provided as-is, and we make no
 * warranties as to its correctness or suitability for
 * any purpose.
 *
 * We hope that it's useful to you.  Enjoy.
 * Copyright 2006-12 LearningPatterns Inc.
 */

package com.javatunes.teach;

//TODO - Import the needed Spring classes
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class TeachMeSpring {

	public static void main(String[] args) {
		System.out.println("We're ready to learn Spring");
		// TODO: Create an ApplicationContext that reads the applicationContext.xml file on the classpath
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		// TODO - Uncomment below and look up the springGuru bean to initialize the teacher variable
		Teacher teacher = ctx.getBean("springGuru", Teacher.class);
		// TODO - Have the teacher teach.
		teacher.teach();
		
		ctx.close();  // Close the context
	}
}